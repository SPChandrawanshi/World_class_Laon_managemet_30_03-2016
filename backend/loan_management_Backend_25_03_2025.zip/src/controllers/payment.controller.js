const paymentService = require('../services/payment.service');
const { convertToCSV } = require('../utils/csv');

const createPayment = async (req, res) => {
  try {
    const { loanId, amount, method, trxId } = req.body;
    const payment = await paymentService.submitPayment(loanId, amount, method, trxId);
    res.status(201).json({ success: true, message: 'Payment submitted for verification', payment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const verifyPayment = async (req, res) => {
  try {
    const payment = await paymentService.verifyPayment(req.params.id);
    res.status(200).json({ success: true, message: 'Payment verified', payment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getPayments = async (req, res) => {
  try {
    if (req.user.role === 'ADMIN' || req.user.role === 'STAFF') {
        const payments = await paymentService.getAllPayments();
        res.status(200).json({ success: true, count: payments.length, payments });
    } else {
        const payments = await paymentService.getPaymentsByUser(req.user.id);
        res.status(200).json({ success: true, count: payments.length, payments });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const exportPayments = async (req, res) => {
  try {
    const payments = await paymentService.getAllPayments();
    
    // Format data for CSV
    const csvData = payments.map(p => ({
      id: p.id,
      borrower: p.loan?.user?.name || 'Unknown',
      loanId: p.loanId,
      amount: p.amount,
      lateAmount: p.lateAmount || 0,
      totalAmount: p.amount + (p.lateAmount || 0),
      status: p.status,
      method: p.method,
      trxId: p.trxId || 'N/A',
      paidAt: p.paidAt ? new Date(p.paidAt).toLocaleDateString() : 'Pending',
      createdAt: new Date(p.createdAt).toLocaleDateString()
    }));

    const headers = [
      { label: 'Payment ID', key: 'id' },
      { label: 'Borrower', key: 'borrower' },
      { label: 'Loan ID', key: 'loanId' },
      { label: 'Amount', key: 'amount' },
      { label: 'Late Fee', key: 'lateAmount' },
      { label: 'Total Paid', key: 'totalAmount' },
      { label: 'Status', key: 'status' },
      { label: 'Method', key: 'method' },
      { label: 'Transaction ID', key: 'trxId' },
      { label: 'Payment Date', key: 'paidAt' },
      { label: 'Created At', key: 'createdAt' }
    ];

    const csv = convertToCSV(csvData, headers);
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=financial_report_${new Date().toISOString().split('T')[0]}.csv`);
    res.status(200).send(csv);
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updatePayment = async (req, res) => {
  try {
    const { trxId, method } = req.body;
    const payment = await paymentService.updatePaymentProof(req.params.id, { trxId, method });
    res.status(200).json({ success: true, message: 'Payment proof updated', payment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = { createPayment, verifyPayment, getPayments, exportPayments, updatePayment };
